main()
{
  printf("With searching comes loss\n");
  printf("and the presence of absence:\n");
  printf("Website not found!\n");
}

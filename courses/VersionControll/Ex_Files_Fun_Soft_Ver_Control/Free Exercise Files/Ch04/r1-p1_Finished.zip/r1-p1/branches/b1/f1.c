main()
{
  printf("With searching comes loss\n");
  printf("and the presence of absence:\n");
  printf("Website not found!\n");
}

feature1()
{
  printf("No more available space\n");
  printf("Look to the cloud\n");
  printf("Your hard drive is full!\n");
}

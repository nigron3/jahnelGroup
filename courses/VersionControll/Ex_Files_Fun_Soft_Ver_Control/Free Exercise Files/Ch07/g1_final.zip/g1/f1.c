main()
{
  printf("With searching comes loss\n");
  printf("and the presence of absence\n");
  printf("Node not found!\n");
}

feature1()
{
  printf("No available space\n");
  printf("Look to the cloud");
  printf("Your drive is full!\n");
}
